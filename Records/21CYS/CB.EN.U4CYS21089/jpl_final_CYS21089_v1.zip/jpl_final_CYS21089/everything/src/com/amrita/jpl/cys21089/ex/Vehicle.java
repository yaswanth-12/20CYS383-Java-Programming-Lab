package com.amrita.calculator.cys21089;

public class Vehicle {
    boolean run_status = false;
    public void start(){
        System.out.println("[Vehicle] started.");
        run_status = true;
    }

    public void stop() {
        System.out.println("[Vehicle] stopped.");
        run_status = false;
    }
}