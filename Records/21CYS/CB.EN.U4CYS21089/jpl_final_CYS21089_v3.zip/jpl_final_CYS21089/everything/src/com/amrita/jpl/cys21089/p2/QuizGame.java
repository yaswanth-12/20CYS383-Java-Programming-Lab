package com.amrita.jpl.cys21089.p2;

public abstract class QuizGame {
    public abstract void startGame();

    abstract void askQuestion();

    abstract void evaluateAnswer();
}
