package com.amrita.jpl.cys21089.pract.net;

import javax.swing.*;
import java.awt.*;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

class server_gui extends JFrame {
    private JTextArea messageArea;

    private ServerSocket serverSocket;
    private Socket clientSocket;
    private DataInputStream inputStream;

    public server_gui() {
        setTitle("Simple Server");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());

        messageArea = new JTextArea();
        messageArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(messageArea);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);

        try {
            serverSocket = new ServerSocket(2444);
            clientSocket = serverSocket.accept();
            inputStream = new DataInputStream(clientSocket.getInputStream());

            while (true) {
                String message = inputStream.readUTF();
                showMessage("Received: " + message);
            }
        } catch (IOException e) {
            showMessage("An error occurred: " + e.getMessage());
        } finally {
            try {
                if (inputStream != null)
                    inputStream.close();
                if (clientSocket != null)
                    clientSocket.close();
                if (serverSocket != null)
                    serverSocket.close();
            } catch (IOException e) {
                showMessage("An error occurred while closing the server: " + e.getMessage());
            }
        }
    }

    private void showMessage(String message) {
        SwingUtilities.invokeLater(() -> messageArea.append(message + "\n"));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            server_gui server = new server_gui();
            server.setVisible(true);
        });
    }

}
