package com.amrita.jpl.cys21089.endsem;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;


/**
 * @author Yaswanth Gadamsetti
 * @version 1.0
 *
 */

/**
 * This Class is File class. it will save the file informations.
 *
 * */

// File class
class File {

    /**
     * @params Attributes
     * */
    private String fileName;
    private long fileSize;

    /**
     * getters and setters for all attributes, displayFileDetails()
     * */
    public File(String fileName, long fileSize) {
        this.fileName = fileName;
        this.fileSize = fileSize;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileName() {
        return fileName;
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    public void displayFileDetails() {
        System.out.println("File Name: " + fileName);
        System.out.println("File Size: " + fileSize);
    }
}

/**
 * This is Document class extended from File class.
 * */

class Document extends File {
    private String documentType;

    public Document(String fileName, long fileSize, String documentType) {
        super(fileName, fileSize);
        this.documentType = documentType;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    @Override
    public void displayFileDetails() {
        super.displayFileDetails();
        System.out.println("Document Type: " + documentType);
    }
}

/**
 * This is Image class extended from File class.
 * */
// Image class
class Image extends File {
    private String resolution;

    public Image(String fileName, long fileSize, String resolution) {
        super(fileName, fileSize);
        this.resolution = resolution;
    }

    public String getResolution() {
        return resolution;
    }

    public void setResolution(String resolution) {
        this.resolution = resolution;
    }

    @Override
    public void displayFileDetails() {
        super.displayFileDetails();
        System.out.println("Resolution: " + resolution);
    }
}

/**
 * This is Video class extended from File class.
 * */

// Video class
class Video extends File {
    private String duration;

    public Video(String fileName, long fileSize, String duration) {
        super(fileName, fileSize);
        this.duration = duration;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    @Override
    public void displayFileDetails() {
        super.displayFileDetails();
        System.out.println("Duration: " + duration);
    }
}

/**
 * This is interface "FileManager" to add, save, delete, load and display the files.
 * */

interface FileManager {
    void addFile(File file);
    void deleteFile(String fileName);
    void displayAllFiles();
    void saveToFile();
    void loadFromFile();
    ArrayList<File> getFiles();
}

/**
 * This FileManagerImpl implements Filemanger interface.
 * */
class FileManagerImpl implements FileManager {
    private ArrayList<File> files;

    public FileManagerImpl() {
        files = new ArrayList<File>();
    }

    @Override
    public void addFile(File file) {
        }



    @Override
    public void deleteFile(String fileName) {
        files.removeIf(file -> file.getFileName().equals(fileName));
    }

    @Override
    public void displayAllFiles() {

    }

    @Override
    public void saveToFile() {
        String filePath = "D:\\old pc\\Amrita\\#Semester 4\\Java Programming\\Java Project\\jpl_FinalLab\\src\\data.txt";
        try {
            FileReader reader = new FileReader(filePath);

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void loadFromFile() {

    }

    @Override
    public ArrayList<File> getFiles() {
        return null;
    }

}

/**
 * This File_Management_SystemUI has all the GUI and ActionListeners that are required.
 * */

public class File_Management_SystemUI extends JFrame {

    private JTable contactTable;
    private DefaultTableModel tableModel;

    private JTextField nameField;
    private JTextField sizeField;
    private JComboBox<String> fileTyeField;

    private JButton addButton;
    private JButton deleteButton;
    private final JButton refreshbutton;
    FileManagerImpl Manager;

    public File_Management_SystemUI() {
        setTitle("End Semester Assignment File Manager");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900,300);

        tableModel = new DefaultTableModel(new Object[]{"Full Name", "File Size", "File Type"}, 0);
        contactTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(contactTable);


        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(1, 3));

        JLabel nameLabel = new JLabel("Name:");
        nameField = new JTextField();
        JLabel sizeLabel = new JLabel("File Size:");
        sizeField = new JTextField();

        String[] options = {"Document", "Image", "Video"};
        JLabel fileTypeLabel = new JLabel("File Type:");
        fileTyeField = new JComboBox<String>(options);

        formPanel.add(nameLabel);
        formPanel.add(nameField);
        formPanel.add(sizeLabel);
        formPanel.add(sizeField);
        formPanel.add(fileTypeLabel);
        formPanel.add(fileTyeField);

        JPanel buttonPanel = new JPanel();

        addButton = new JButton("Add File");
        addButton.addActionListener(new AddButtonListener());
        buttonPanel.add(addButton);

        deleteButton = new JButton("Delete File");
        deleteButton.addActionListener(new DeleteButtonListener());
        buttonPanel.add(deleteButton);

        refreshbutton = new JButton("Refresh");
        buttonPanel.add(refreshbutton);

        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(formPanel, BorderLayout.NORTH);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        Container container = getContentPane();
        container.add(mainPanel);

        //pack();
        setLocationRelativeTo(null);
    }

    private void clearbutton() {
        nameField.setText("");
        sizeField.setText("");
    }

    private class AddButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String name = nameField.getText();
            int fileSize = Integer.parseInt(sizeField.getText());
            String fileType = String.valueOf(fileTyeField.getSelectedItem());

            Object[] rowData = {name, fileSize, fileType};
            tableModel.addRow(rowData);

            /*The below two lines are dummy*/
            File file = new File("\\data.txt",'r');
            Manager.addFile(file);

            clearbutton();
        }
    }

    private class DeleteButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = contactTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(File_Management_SystemUI.this, "Please select a document/com.amrita.jpl.com.amrita.jpl.cys21089.endsem.Image/com.amrita.jpl.com.amrita.jpl.cys21089.endsem.Video to delete.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int confirmDialogResult = JOptionPane.showConfirmDialog(File_Management_SystemUI.this, "Are you sure you want to delete this document/com.amrita.jpl.com.amrita.jpl.cys21089.endsem.Image/com.amrita.jpl.com.amrita.jpl.cys21089.endsem.Video?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirmDialogResult == JOptionPane.YES_OPTION) {
                tableModel.removeRow(selectedRow);
            }
        }
    }


    /**
     * Main function to start the GUI and load the data from file.
     * */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new File_Management_SystemUI().setVisible(true));
    }
}
